To use this application on a 32bit Linux system:

1. Unpack the archive.
2. Open terminal in the folder where you have unpacked the archive.
3. Double click on Weather_App_32bit or alternatively:
4. Run ./Weather_App_32bit in the terminal.
Enjoy !
